
using Microsoft.AspNetCore.Mvc;

namespace MeuProjeto.Controllers
{
    public class AlunoController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.Nome = "Ana Beatriz";
            ViewBag.Curso = "Análise e Desenvolvimento de Sistemas";
            ViewBag.Semestre = 1;

            return View();
        }

        public IActionResult Detalhes(int id)
        {
            ViewBag.Id = id;
            return View();
        }
    }
}
